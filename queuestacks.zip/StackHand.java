// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Queues and Stacks>

package projects.project6.hands;
import projects.project6.cards.PlayingCard;
import projects.project6.jsjf.LinkedStack;

//Write a class called StackHand which implements the HandOfCards interface 
//using the LinkedStack class from the jsjf package
public class StackHand implements HandOfCards {
		//implements the HandOfCards interface 
		//using the LinkedStack class from the jsjf package
        private LinkedStack<PlayingCard> stacks;
        //Write a class called StackHand
        public StackHand() {
                stacks = new LinkedStack<PlayingCard>();
        }
        
        //So getValue should probably 
        //return either the value of the top card or 
        //*even 0 since you could argue that a StackHand has no value until a card is played.
		public int getValue() {
			return 0;
		}
		
		//play() which removes a PlayingCard from the hand and returns the PlayingCard
		//use pop() in order to remove 
        public PlayingCard play() {
                return stacks.pop();
        }
        
		//which returns the number of PlayingCards in the hand
        //for size() use the push function so it returns the number of cards 
        public void size(PlayingCard firstvalue) {
                stacks.push(firstvalue);
        }
       
        
        //print(), just print out my hand
        public void print() {
                System.out.println(stacks);
        }

}
