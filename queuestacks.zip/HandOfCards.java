// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Queues and Stacks>

package projects.project6.hands;

import projects.project6.cards.PlayingCard;

public interface HandOfCards {
	public void size(PlayingCard firstvalue);
	public void print();
	public int getValue();
}
