// CSE 205     : <Class 205> / <Tuesday and Thursday>
// Projects  : <Classes>
// Author      : <Parth Patel> & <1219217324>
// Description : <Queues and Stacks>

package warproject;
import java.util.Scanner;
import projects.project6.cards.PlayingCard;
import projects.project6.hands.StackHand;

//In a separate driver class called WarGame.java, deal 2 StackHands of cards. The hands should have the same 
//number of cards.  
//Simulate a game of War as follows:
	//Play the top card from each hand. 
	//The player with the highest card wins the round and gets a point.
	//When the hands are empty, print the score for each player
public class WarGame {
	public static void main(String[] args) {
		//In a separate driver class called WarGame.java, deal 2 StackHands of cards.
		//Initialize your playing card values
		//first value
		PlayingCard firstvalue;
		firstvalue = new PlayingCard();
		//second value
		PlayingCard secondvalue;
		secondvalue = new PlayingCard();
		//third value
		PlayingCard thirdvalue;
		thirdvalue = new PlayingCard();
		//fourth value
		PlayingCard fourthvalue;
		fourthvalue = new PlayingCard();
		//In a separate driver class called WarGame.java, deal 2 StackHands of cards.
		//Initialize the StackHand made in other package
		//deck number one, initialize the first StackHand made in other package
		StackHand decknumberone;
		decknumberone = new StackHand();
		//deck number two, initialize the second StackHand made in other package
		StackHand decknumbertwo; 
		decknumbertwo = new StackHand();
		//The hands should have the same 
		//number of cards.
		//add the first value to the deck number one
		decknumberone.size(firstvalue);
		//add the second value to the deck number one
		decknumberone.size(secondvalue);
		//add the third value to the deck number two
		decknumbertwo.size(thirdvalue);
		//add the fourth value to the deck number two
		decknumbertwo.size(fourthvalue);
		//initialize variables
		int valueone; 
		valueone=0;
		int valuetwo;
		valuetwo=0;
		
		//use for loop in order to find finals scores for each player
		//Play the top card from each hand. The player with the highest card wins the round and gets a point.
		//When the hands are empty, print the score for each player
		int startingnumber;
		for(startingnumber = 0;startingnumber<2;startingnumber++) {
			//initialize variables that are going to be compared.
			int firstdeck;
			firstdeck = decknumberone.play().getValue();
			int seconddeck;
			seconddeck = decknumbertwo.play().getValue();
			//Play the top card from each hand. 
			//The player with the highest card wins the round and gets a point.
			if(firstdeck<seconddeck) {
				valuetwo++;
					}
			//Play the top card from each hand. 
			//The player with the highest card wins the round and gets a point.
			else if(firstdeck>seconddeck)
				valueone++;
			//Play the top card from each hand. 
			//The player with the highest card wins the round and gets a point.
			else {
				valueone++;
				valuetwo++;
			}
		}
		
		//Play the top card from each hand. The player with the highest card wins the round and gets a point.
		//When the hands are empty, print the score for each player
		System.out.println();
		System.out.println("Final Scores:");
		System.out.println();
		//When the hands are empty, print the score for each player
		//Printing scores for each players
		System.out.println("Player" +" "+ "0"+" "+ ":"+" "+valueone);
		System.out.println();
		System.out.println("Player" + " "+ "1"+" "+ ":"+" "+valuetwo);
	}
}
